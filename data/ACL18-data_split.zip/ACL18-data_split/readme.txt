train and test: the full ATIS dataset
train_intent_5/10/20: full few-shot learning dataset for intent detection with 5/10/20 shot
train_intent_5/10/20_fill_3_300: partial few-shot learning dataset for intent detection with 5/10/20 shot
train_slot_5/10/20: few-shot learning dataset for slot filling with 5/10/20 shot

In each folder:
train/test.seq.in: tokenized sentence
train/test.seq.out: slot label for each token
train/test.label: intent label
