intent_REs.txt: contains the intent REs
slot_REs_for_input_output_level.txt: contains the slot REs for the input and output level methods (Sec. 3.2, 3.4)
slot_REs_for_attention.txt: contains the slot REs for the two-side attention method (Sec. 3.3)

The first few lines of each file contains the description of the file format.